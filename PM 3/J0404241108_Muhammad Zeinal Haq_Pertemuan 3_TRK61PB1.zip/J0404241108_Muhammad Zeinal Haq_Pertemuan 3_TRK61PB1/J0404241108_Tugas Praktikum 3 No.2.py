#Tugas 2
name = input("Masukkan nama lengkap anda: ")
print("Selamat datang di SV IPB Class, " + name)
task = input("Ketik NIM untuk melanjutkan: ")
print("Penugasan Dasar Pemrograman No.2")
True and False
False or True
1 == 1 and 2 == 1
"true" == True
False and 0!= 0
not (10 == 1 or 1000 == 1000)
"pete" == "jengkol" and (not (3 == 4 or 3 == 3))
3 == 3 and not ("test" == "test" or "Python" == "Fun")
print(True and False)
print(False or True)
print(1 == 1 and 2 == 1)
print("true" == True)
print(False and 0!= 0)
print(not (10 == 1 or 1000 == 1000))
print("pete" == "jengkol" and (not (3 == 4 or 3 == 3)))
print(3 == 3 and not ("test" == "test" or "Python" == "Fun"))